package com.minhui.networkcapture;

/**
 * @author minhui.zhu
 *         Created by minhui.zhu on 2018/5/6.
 *         Copyright © 2017年 Oceanwing. All rights reserved.
 */

public interface AppConstants {

    String HAS_FULL_USE_APP = "has_full_use_app";
    String HAS_SHOW_RECOMMAND = "has_show_recommand";
    String DATA_SAVE = "saveData";
}
