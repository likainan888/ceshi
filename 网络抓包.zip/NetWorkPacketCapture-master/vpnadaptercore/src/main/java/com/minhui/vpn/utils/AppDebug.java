package com.minhui.vpn.utils;


/**
 * Created by zengzheying on 15/12/28.
 */
public class AppDebug {

    public static final boolean IS_DEBUG = true;

}
